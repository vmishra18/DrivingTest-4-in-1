export type RootStackParamList = {
  Home: undefined;
  Theory: undefined;
  Hazard: undefined;
  Highway: undefined;
  Signs: undefined;
};